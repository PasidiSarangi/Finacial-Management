import mongoose from "mongoose";

const itemSchema = new mongoose.Schema({
    petId: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    userId: {
        type: String,
        required: true,
        trim: true
    },
    fname: {
        type: String,
        required: true,
        trim: true
    },
    lname: {
        type: String,
        required: true,
        trim: true
    },
    p_nb: {
        type: String,
        required: true,
        trim: true
    },
    route: {
        type: String,
        required: true,
        trim: true
    },
    date: {
        type: String,
        required: true,
        trim: true
    },
    nb_tickets: {
        type: String,
        required: true,
        trim: true
    },
    p_method: {
        type: String,
        required: true,
        trim: true
    },
    crd_details: {
        type: String||null,
       // required: true,
        trim: true
    },
    ttl_amount: {
        type: String,
        required: true,
        trim: true
    },
    
   
  
  
}, { timestamps: true });

const Item = mongoose.model("Payments", itemSchema);

export default Item;
