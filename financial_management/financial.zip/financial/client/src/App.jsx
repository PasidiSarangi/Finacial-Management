import {BrowserRouter ,Routes,Route } from 'react-router-dom';

import About from './Pages/About';
import Signin from './Pages/Signin';
import SignUp from './Pages/SignUp';
import Profile from './Pages/Profile';
import Header from './components/header';
import PrivateRoutes from './components/PrivateRoutes';
import AddItem from './Pages/AddPayment';
import ItemProfile from './Pages/PaymentProfile';

import AllDetails from './Pages/FinancialHome';
import UpdateItem from './Pages/UpdateItem';
import Refund from './Pages/Refund';
import RefundProfile from './Pages/RefundProfile';







export default function App() {
  return <BrowserRouter>
<Header/>
  <Routes>
    <Route path="/" element={<AllDetails/>}></Route>
    <Route path="/about" element={<About/>}></Route>
    <Route path="/sign-in" element={<Signin/>}></Route>
    <Route path="/additem" element={<AddItem/>}></Route>
    <Route path="/refund" element={<Refund/>}></Route>
    <Route path="/sign-up" element={<SignUp/>}></Route>

    <Route element={<PrivateRoutes/>}>
    <Route path="/profile" element={<Profile/>}></Route>
    <Route path="/items" element={<ItemProfile/>}></Route>
    <Route path="/refunds" element={<RefundProfile/>}></Route>

    <Route path="/update-item/:id" element={<UpdateItem/>}></Route>


    </Route>
 
    
  </Routes>
  
  </BrowserRouter>
  
}
