import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './css/FinancialHome.css';

export default function AllDetails() {
  // const [orders, setOrders] = useState([]);
  // const [searchQuery, setSearchQuery] = useState('');

  // const [filteredOrders, setFilteredOrders] = useState([]);

  // useEffect(() => {
  //   fetchOrders();
  // }, []);

  // const fetchOrders = async () => {
  //   try {
  //     const response = await fetch(`/api/auth/users/items`);
  //     if (!response.ok) {
  //       throw new Error('Failed to fetch orders');
  //     }
  //     const data = await response.json();
  //     setOrders(data);
  //     // Initially set filtered orders to all orders
  //     setFilteredOrders(data);
  //   } catch (error) {
  //     console.error('Error fetching orders:', error);
  //   }
  // };

  // const handleSearch = (e) => {
  //   filterdata(searchQuery)
  // }
  //   const filterdata=(searchQuery)=>{
  //     const filterData=filteredOrders.filter(customer=>
  //       customer.productName&&customer.productName.toLowerCase().includes(searchQuery.toLowerCase())
  //     );
  //     setFilteredOrders(filterData)
 


   
  // };



  
  return (
    // Import CSS for styling
    

        <div className="financial-home">
          {/* Hero Section */}
          <div className="hero">
            <h1>Manage Your Finances Effortlessly</h1>
            <p>Track payments, analyze financial data, and optimize your budget with ease.</p>
            <button className="cta-button"><a href='/additem'>Get Started</a></button>
          </div>
    
          {/* Features Section */}
          <div className="features">
            <div className="feature-card">
              <h3>Secure Transactions</h3>
              <p>We ensure your payments are encrypted and safe.</p>
            </div>
            <div className="feature-card">
              <h3>Real-time Analytics</h3>
              <p>Monitor your income, expenses, and trends in real time.</p>
            </div>
            <div className="feature-card">
              <h3>Budget Planning</h3>
              <p>Smart tools to help you plan your monthly budget.</p>
            </div>
          </div>
    
          {/* Call-to-Action Section */}
          <div className="cta-section">
            <h2>Start Managing Your Finances Today</h2>
            <p>Sign up now and take control of your financial future.</p>
            <button className="cta-button"><a href='/sign-up'>Sign Up</a></button>
          </div>
        </div>
 
    
    
  );
}
